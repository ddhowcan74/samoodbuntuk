สมุดพกส่วนตัว — DEV / PROD workflow

หลักการ
- DEV = พื้นที่ทดลองสำหรับการแก้ไข/เพิ่มฟีเจอร์
- PROD = เว็บหลักที่แชร์ให้คนอื่นใช้งาน
- ทุกคำขอแก้ไขใหม่จะทำใน DEV ก่อน
- จะไม่ถือว่าแก้เว็บหลักจนกว่าผู้ใช้จะยืนยันว่า “เอาขึ้นตัวหลัก/ขึ้น Production”

โครงสร้าง
- index.html = DEV build (มีป้าย DEV · V2)
- production/index.html = Production build สำหรับปล่อยหลังผู้ใช้ยืนยัน

การ Deploy ครั้งแรก
1. สร้าง Netlify site แยกสำหรับ DEV เช่น samoodbuntuk-dev
2. ลากไฟล์/โฟลเดอร์ DEV ขึ้น site DEV
3. เก็บ samoodbuntuk.netlify.app เป็น Production ห้ามใช้ทดลอง

เมื่อมีการแก้ไข
1. แก้ DEV
2. ทดสอบ DEV
3. ให้ผู้ใช้ตรวจและยืนยัน
4. เมื่อผู้ใช้ยืนยัน จึงนำ DEV build ที่ผ่านการทดสอบไป Deploy ทับ Production

หมายเหตุ
- เว็บนี้เก็บข้อมูลด้วย localStorage แยกตาม browser/device
- DEV และ PROD จึงไม่ควรใช้ข้อมูลเดียวกันในการทดสอบ
